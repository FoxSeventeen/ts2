# 快递管理信息系统 (Express Management System)

## 📋 项目简介

这是一个基于Python开发的快递管理信息系统，实现了快递单管理、用户管理、网点管理、物流追踪、数据可视化等核心功能。系统采用CSV文件存储数据，支持多种索引技术（B+树、哈希索引、Trie树）以提高查询效率。

### 核心特性

✅ **完整的CRUD操作** - 用户、快递单、网点、快递员的增删改查  
✅ **多种索引支持** - B+树有序索引、哈希散列索引、Trie前缀索引  
✅ **空间查询** - 基于经纬度的配送区域范围查询  
✅ **物流可视化** - Matplotlib绘制快递轨迹路线图  
✅ **视图统计** - 网点寄件量、快递员派送量、订单状态分布  
✅ **图形界面** - Tkinter GUI，操作简单直观  
✅ **编码兼容** - 自动检测UTF-8/GBK/GB2312编码  

---

## 📂 项目结构

```
ts2/
├── database/                    # 数据存储目录
│   ├── data/                    # CSV数据文件
│   │   ├── User.csv            # 用户表（15条记录）
│   │   ├── ExpressOrder.csv    # 快递单表（15条记录）
│   │   ├── ExpressTrack.csv    # 快递轨迹表（48条记录）
│   │   ├── ExpressBranch.csv   # 快递网点表（15个网点）
│   │   ├── Courier.csv         # 快递员表（10名快递员）
│   │   └── DeliveryZone.csv    # 配送区域表（15个区域）
│   ├── index/                   # 索引文件目录
│   │   ├── ExpressOrder_orderId_hash.idx  # 快递单号哈希索引
│   │   ├── User_uphone_hash.idx           # 用户手机号哈希索引
│   │   └── phone_order_trie.idx           # 手机号前缀Trie索引
│   └── views.meta               # 视图元数据
│
├── db_core.py                   # 数据库核心模块（CRUD操作）
├── index_core.py                # 索引管理模块（B+树、哈希索引）
├── trie_index.py                # Trie前缀索引模块
├── spatial_core.py              # 空间查询模块
├── visualization.py             # 数据可视化模块
├── GUI.py                       # 图形界面模块
├── main.py                      # 主程序入口
├── phone_search_example.py      # 手机号前缀查询示例
├── DATA_PREVIEW.md              # 测试数据说明文档
└── README.md                    # 本文档
```

---

## 🚀 快速开始

### 1. 环境要求

- **Python 版本**: 3.6 或更高
- **依赖库**:
  ```bash
  pip install matplotlib
  # 如果使用Tkinter，某些系统可能需要单独安装
  # Ubuntu/Debian: sudo apt-get install python3-tk
  # macOS: 已内置
  # Windows: Python安装时已包含
  ```

### 2. 安装与运行

```bash
# 克隆或下载项目
git clone https://github.com/FoxSeventeen/ts2.git
cd ts2

# 直接运行主程序（图形界面）
python main.py

# 或运行GUI模块
python GUI.py
```

### 3. 数据初始化

首次运行时，系统会自动构建索引。如果需要手动初始化：

```python
from index_core import HashIndex, build_order_index
from trie_index import PhoneTrieIndex

# 构建快递单号有序索引
build_order_index()

# 构建用户手机号哈希索引
user_phone_index = HashIndex("User", "uphone")
user_phone_index.build()

# 构建手机号前缀Trie索引
trie_index = PhoneTrieIndex()
trie_index.build()
```

---

## 📖 功能说明

### 1. 用户管理

#### 新增用户
```python
from db_core import insert_user

user_data = {
    'uid': 'U016',
    'uname': '张三',
    'utype': '普通用户',
    'uphone': '13800138016',
    'uprovince': '北京市',
    'ucity': '北京市',
    'uaddress': '朝阳区建国路88号',
    'uidcard': '110101199001011234'
}
insert_user(user_data)
```

#### 查询用户
```python
from db_core import query_user

# 按手机号查询
users = query_user({'uphone': '13800138001'})

# 按城市查询
users = query_user({'ucity': '北京市'})

# 查询所有用户
all_users = query_user()
```

#### 更新用户
```python
from db_core import update_user

update_data = {'uaddress': '新地址：朝阳区望京SOHO'}
update_user('U001', update_data)
```

#### 删除用户
```python
from db_core import delete_user

delete_user('U016')  # 注意：有关联快递单的用户无法删除
```

---

### 2. 快递单管理

#### 新增快递单
```python
from db_core import insert_express_order

order_data = {
    'orderId': 'EXP016',
    'senderId': 'U001',        # 寄件人UID
    'receiverId': 'U002',      # 收件人UID
    'goodsName': '电子产品',
    'goodsWeight': '2.5',
    'sendBranchId': 'B001',    # 寄件网点
    'targetBranchId': 'B005'   # 目标网点
}
insert_express_order(order_data)
```

#### 查询快递单

**普通查询**：
```python
from db_core import query_express_order

# 按快递单号查询（不使用索引）
orders = query_express_order({'orderId': 'EXP001'})

# 按状态查询
orders = query_express_order({'orderStatus': '3'})  # 派送中的快递

# 按网点查询
orders = query_express_order({'sendBranchId': 'B001'})
```

**索引查询**（更快）：
```python
# 使用哈希索引查询快递单号
orders = query_express_order({'orderId': 'EXP001'}, use_index=True)
```

#### 更新快递状态
```python
from db_core import update_express_order

# 更新状态（会自动校验状态流转合法性）
update_data = {'orderStatus': '3'}  # 0→1→2→3→4 或 →5（异常）
update_express_order('EXP001', update_data)
```

#### 删除快递单
```python
from db_core import delete_express_order

delete_express_order('EXP016')
```

---

### 3. 手机号前缀查询（Trie索引）

**基本用法**：
```python
from phone_search_example import search_orders_by_phone_prefix

# 查询手机号前缀为 "138" 的所有快递
results = search_orders_by_phone_prefix("138")

# 查询完整手机号
results = search_orders_by_phone_prefix("13800138001")

# 打印结果
for order in results:
    print(f"快递单号: {order['快递单号']}")
    print(f"寄件人: {order['寄件人']} ({order['寄件人电话']})")
    print(f"收件人: {order['收件人']} ({order['收件人电话']})")
```

**高级用法**：
```python
from trie_index import PhoneTrieIndex

# 初始化索引
trie_index = PhoneTrieIndex()

# 加载已有索引（如果存在）
if trie_index.load():
    print("索引加载成功")
else:
    # 构建新索引
    trie_index.build()

# 查询前缀
order_ids = trie_index.search_prefix("138")
print(f"找到 {len(order_ids)} 个快递单: {order_ids}")

# 数据更新后重建索引
trie_index.rebuild()
```

---

### 4. 快递员派送统计

```python
from db_core import join_courier_orders

# 查询快递员C001在2024-12-13的派送记录
results = join_courier_orders('C001', '2024-12-13')

for record in results:
    print(f"快递单号: {record['快递单号']}")
    print(f"收件人: {record['收件人姓名']} ({record['收件人电话']})")
    print(f"物品: {record['物品名称']}")
    print(f"状态: {record['状态']}")
```

---

### 5. 网点寄件量统计（视图查询）

#### 网点月度寄件量
```python
from db_core import query_view

# 查询所有网点的月度统计
results = query_view("BranchMonthlySend")

# 查询特定网点的特定月份
results = query_view("BranchMonthlySend", {
    'sendBranchId': 'B001',
    'month': '2024-12'
})

for stat in results:
    print(f"网点: {stat['sendBranchId']}, 月份: {stat['month']}, 寄件量: {stat['sendCount']}")
```

#### 快递员每日派送统计
```python
# 查询所有快递员的每日统计
results = query_view("CourierDailyStats")

# 查询特定快递员的特定日期
results = query_view("CourierDailyStats", {
    'courierId': 'C001',
    'date': '2024-12-13'
})
```

#### 快递状态分布统计
```python
# 查询所有状态的分布
results = query_view("OrderStatusStats")

for stat in results:
    print(f"状态: {stat['statusName']}, 数量: {stat['count']}")
```

---

### 6. 空间范围查询

```python
from spatial_core import spatial_zone_query

# 查询北京朝阳区的配送区域（经纬度范围）
zones = spatial_zone_query(
    branch_id="B001",
    min_lng=116.43,
    min_lat=39.88,
    max_lng=116.50,
    max_lat=40.02
)

for zone in zones:
    print(f"区域: {zone['zoneName']}, 覆盖: {zone['coverageArea']}")
```

---

### 7. 物流轨迹可视化

```python
from spatial_core import express_spatial_track
from visualization import visualize_track_window

# 查询快递轨迹（带坐标信息）
track_data = express_spatial_track('EXP001')

# 在独立窗口中可视化
visualize_track_window(track_data)
```

**可视化效果**：
- 起点：绿色标记
- 终点：红色标记
- 中间站点：蓝色标记
- 路线：蓝色连线
- 站点标签：显示网点名称和操作类型

---

## 🗂️ 数据模型

### 表结构说明

#### 1. User（用户表）
| 字段名 | 类型 | 说明 | 示例 |
|--------|------|------|------|
| uid | VARCHAR(20) | 用户ID（主键） | U001 |
| uname | VARCHAR(50) | 姓名 | 张三 |
| utype | VARCHAR(20) | 用户类型 | 普通用户/商家用户/快递员 |
| uphone | VARCHAR(11) | 手机号 | 13800138001 |
| uprovince | VARCHAR(50) | 省份 | 北京市 |
| ucity | VARCHAR(50) | 城市 | 北京市 |
| uaddress | VARCHAR(200) | 详细地址 | 朝阳区建国路88号 |
| uidcard | VARCHAR(18) | 身份证号 | 110101199001011234 |

#### 2. ExpressOrder（快递单表）
| 字段名 | 类型 | 说明 | 示例 |
|--------|------|------|------|
| orderId | VARCHAR(20) | 快递单号（主键） | EXP001 |
| senderId | VARCHAR(20) | 寄件人ID（外键→User.uid） | U001 |
| receiverId | VARCHAR(20) | 收件人ID（外键→User.uid） | U004 |
| goodsName | VARCHAR(100) | 物品名称 | 电子产品 |
| goodsWeight | DECIMAL(10,2) | 物品重量（kg） | 2.5 |
| sendBranchId | VARCHAR(20) | 寄件网点（外键→ExpressBranch.branchId） | B001 |
| targetBranchId | VARCHAR(20) | 目标网点 | B004 |
| sendTime | DATETIME | 寄件时间 | 2024-12-10 08:30:00 |
| estimatedTime | DATETIME | 预计送达时间 | 2024-12-13 18:00:00 |
| orderStatus | CHAR(1) | 快递状态 | 0-5（见状态说明） |

**快递状态说明**：
- `0` - 待收件
- `1` - 已收件
- `2` - 中转中
- `3` - 派送中
- `4` - 已签收
- `5` - 异常

**状态流转规则**：
```
0（待收件） → 1（已收件） → 2（中转中） → 3（派送中） → 4（已签收）
                ↓              ↓              ↓
                5（异常）    5（异常）      5（异常）
```

#### 3. ExpressTrack（快递轨迹表）
| 字段名 | 类型 | 说明 | 示例 |
|--------|------|------|------|
| orderId | VARCHAR(20) | 快递单号（外键→ExpressOrder.orderId） | EXP001 |
| operateBranchId | VARCHAR(20) | 当前操作网点 | B001 |
| prevBranchId | VARCHAR(20) | 上个网点（NULL=起点） | NULL |
| nextBranchId | VARCHAR(20) | 下个网点（NULL=终点） | B002 |
| operateType | CHAR(1) | 操作类型 | 0-4（见说明） |
| operateTime | DATETIME | 操作时间 | 2024-12-10 08:30:00 |

**操作类型说明**：
- `0` - 收件（快递员上门揽件）
- `1` - 中转入库（到达分拨中心）
- `2` - 中转出库（从分拨中心发出）
- `3` - 派送（派送员开始配送）
- `4` - 签收（收件人签收）

#### 4. ExpressBranch（快递网点表）
| 字段名 | 类型 | 说明 | 示例 |
|--------|------|------|------|
| branchId | VARCHAR(20) | 网点ID（主键） | B001 |
| branchName | VARCHAR(100) | 网点名称 | 北京朝阳营业点 |
| branchType | VARCHAR(20) | 网点类型 | 分拨中心/营业点 |
| coordinateRange | VARCHAR(100) | 坐标范围 | 116.43,39.91,116.47,39.95 |
| province | VARCHAR(50) | 省份 | 北京市 |
| city | VARCHAR(50) | 城市 | 北京市 |
| address | VARCHAR(200) | 详细地址 | 朝阳区建国路100号 |

**坐标格式说明**：
```
格式: minLng,minLat,maxLng,maxLat
示例: 116.43,39.91,116.47,39.95
说明: 定义一个矩形区域，可视化时取中心点
```

#### 5. Courier（快递员表）
| 字段名 | 类型 | 说明 | 示例 |
|--------|------|------|------|
| courierId | VARCHAR(20) | 快递员ID（主键） | C001 |
| courierName | VARCHAR(50) | 姓名 | 周九 |
| courierPhone | VARCHAR(11) | 手机号（外键→User.uphone） | 13800138007 |
| branchId | VARCHAR(20) | 所属网点 | B001 |
| workStatus | VARCHAR(20) | 工作状态 | 在职/休假 |

#### 6. DeliveryZone（配送区域表）
| 字段名 | 类型 | 说明 | 示例 |
|--------|------|------|------|
| zoneId | VARCHAR(20) | 区域ID（主键） | Z001 |
| branchId | VARCHAR(20) | 所属网点 | B001 |
| zoneName | VARCHAR(100) | 区域名称 | 朝阳北部区 |
| coordinateRange | VARCHAR(100) | 覆盖范围 | 116.46,39.96,116.50,40.00 |
| coverageArea | VARCHAR(200) | 覆盖区域描述 | 望京、太阳宫 |

---

## 🔍 索引技术说明

### 1. B+树有序索引（快递单号）
- **文件**: `index_core.py` - `build_order_index()`
- **索引字段**: `orderId`
- **存储格式**: 文本文件（`ExpressOrder_orderId.idx`）
- **查询函数**: `search_order_index(order_id)`
- **适用场景**: 精确查找、范围查询

### 2. 哈希散列索引（用户手机号、快递单号）
- **文件**: `index_core.py` - `HashIndex`类
- **索引字段**: `uphone`（用户表）、`orderId`（快递单表）
- **存储格式**: 二进制Pickle文件
- **查询函数**: `HashIndex.search(index_val)`
- **冲突处理**: 链地址法
- **适用场景**: 精确等值查询（O(1)复杂度）

### 3. Trie前缀索引（手机号前缀）
- **文件**: `trie_index.py` - `PhoneTrieIndex`类
- **索引字段**: 手机号（支持前缀匹配）
- **存储格式**: 二进制Pickle文件
- **查询函数**: `PhoneTrieIndex.search_prefix(prefix)`
- **数据结构**: 字典树（Trie）
- **适用场景**: 前缀模糊查询、自动补全

**索引对比**：
| 索引类型 | 查询速度 | 空间占用 | 适用场景 |
|----------|----------|----------|----------|
| B+树 | O(log n) | 中等 | 范围查询、排序 |
| 哈希 | O(1) | 较小 | 精确等值查询 |
| Trie | O(k) | 较大 | 前缀查询（k=前缀长度） |

---

## 🎨 图形界面使用

### 启动GUI
```bash
python main.py
# 或
python GUI.py
```

### 主要功能模块
1. **用户管理**
   - 新增用户
   - 查询用户（支持多条件）
   - 更新用户信息
   - 删除用户

2. **快递管理**
   - 新增快递单
   - 查询快递单（普通/索引查询）
   - 更新快递状态
   - 删除快递单
   - 查询快递轨迹
   - 可视化物流路线

3. **手机号前缀查询**
   - 输入手机号前缀（如 "138"）
   - 查看所有相关快递单
   - 显示寄件人和收件人信息

4. **统计分析**
   - 网点月度寄件量统计
   - 快递员每日派送统计
   - 快递状态分布统计

5. **空间查询**
   - 输入经纬度范围
   - 查询配送区域

---

## 🔧 开发指南

### 添加新的查询功能

1. **在 `db_core.py` 中添加查询函数**：
```python
def query_by_custom_field(field_value):
    """自定义查询函数"""
    orders = read_csv(f"{DATA_DIR}/ExpressOrder.csv")
    results = [o for o in orders if o['customField'] == field_value]
    return results
```

2. **如需索引优化，在 `index_core.py` 中构建索引**：
```python
custom_index = HashIndex("ExpressOrder", "customField")
custom_index.build()
```

3. **在 GUI 中添加界面元素**（可选）

### 添加新的视图

在 `database/views.meta` 中添加视图定义：
```
ViewName|SELECT * FROM ...|2024-12-20 10:00:00|admin
```

然后在 `db_core.py` 的 `query_view` 函数中实现视图逻辑。

---

## ⚠️ 常见问题

### 1. 编码错误：`UnicodeDecodeError`
**原因**：CSV文件编码不匹配  
**解决**：系统已自动支持UTF-8/GBK/GB2312，确保使用修复后的 `db_core.py`

### 2. 索引查询返回空结果
**原因**：索引未构建或索引与数据不同步  
**解决**：
```python
# 重建索引
from index_core import HashIndex
order_index = HashIndex("ExpressOrder", "orderId")
order_index.rebuild()
```

### 3. 快递员派送统计无结果
**原因**：字段名大小写错误（已修复）  
**解决**：使用修复后的 `db_core.py`（`uid` 和 `uname` 均为小写）

### 4. 视图查询失败
**原因**：`views.meta` 文件不存在或格式错误  
**解决**：
```bash
# 创建 views.meta 文件
touch database/views.meta

# 或手动添加视图定义
echo "BranchMonthlySend|SELECT ...|2024-12-20|admin" >> database/views.meta
```

### 5. 可视化窗口无法显示
**原因**：缺少Tkinter或Matplotlib  
**解决**：
```bash
pip install matplotlib
# Ubuntu/Debian
sudo apt-get install python3-tk
```

---

## 📊 测试数据说明

系统内置15个快递单、15个用户、15个网点、10个快递员的测试数据，详细说明请参考 `DATA_PREVIEW.md`。

### 推荐测试快递单
- **EXP001**：跨城长途（5个站点：北京→上海→南京→广州→深圳）
- **EXP011**：上海→广州（4个站点）
- **EXP002**：上海→杭州（直达）

### 推荐测试手机号
- **13800138001**：张三（北京，有多个快递单）
- **13800138004**：赵六（深圳）
- **138**：前缀查询，返回多个结果

---

## 🛠️ 技术栈

- **编程语言**: Python 3.6+
- **数据存储**: CSV文件
- **图形界面**: Tkinter
- **数据可视化**: Matplotlib
- **索引技术**: B+树、哈希表、Trie树
- **编码支持**: UTF-8、GBK、GB2312

---

## 📝 更新日志

### v1.1 (2024-12-20)
- ✅ 修复索引查询返回空结果问题（条件判断错误）
- ✅ 修复新增快递单编码错误（自动检测文件编码）
- ✅ 修复快递员派送统计字段名错误（`uId` → `uid`）
- ✅ 完善网点寄件量统计视图查询功能
- ✅ 新增快递员每日派送统计视图
- ✅ 新增快递状态分布统计视图
- ✅ 新增Trie前缀索引支持手机号前缀查询
- ✅ 新增 `phone_search_example.py` 示例文件
- ✅ 增强错误处理和日志提示

### v1.0 (2024-12-14)
- 初始版本发布
- 实现基本的CRUD操作
- 支持B+树和哈希索引
- 空间范围查询
- 物流轨迹可视化

---

## 🤝 贡献指南

欢迎提交Issue和Pull Request！

### 开发环境搭建
```bash
git clone https://github.com/FoxSeventeen/ts2.git
cd ts2
pip install -r requirements.txt  # 如果有
```

### 代码规范
- 使用PEP 8编码规范
- 函数和类添加文档字符串
- 提交前测试所有功能

---

## 📄 许可证

本项目仅供学习交流使用。

---

## 👥 作者

- **项目维护者**: FoxSeventeen
- **技术支持**: Claude (Anthropic)

---

## 📞 联系方式

如有问题或建议，请通过以下方式联系：
- GitHub Issues: [https://github.com/FoxSeventeen/ts2/issues](https://github.com/FoxSeventeen/ts2/issues)

---

## 🎯 未来计划

- [ ] 支持MySQL/PostgreSQL等关系型数据库
- [ ] 增加Web界面（Flask/Django）
- [ ] 实现用户权限管理
- [ ] 支持实时物流追踪
- [ ] 增加数据分析和报表功能
- [ ] 支持批量导入导出
- [ ] 增加单元测试覆盖

---

**感谢使用快递管理信息系统！**
